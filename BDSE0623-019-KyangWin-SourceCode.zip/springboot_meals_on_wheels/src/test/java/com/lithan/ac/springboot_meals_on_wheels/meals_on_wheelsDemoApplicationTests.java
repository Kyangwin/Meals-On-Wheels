package com.lithan.ac.springboot_meals_on_wheels;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class meals_on_wheelsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

	
	
