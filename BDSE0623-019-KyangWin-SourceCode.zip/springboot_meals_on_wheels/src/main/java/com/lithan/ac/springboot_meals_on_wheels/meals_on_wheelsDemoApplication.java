package com.lithan.ac.springboot_meals_on_wheels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class meals_on_wheelsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(meals_on_wheelsDemoApplication.class, args);
	}

}
